# React Concepts - Tailwind CSS Setup

A modern React application showcasing React hooks, state management, and API integration with beautiful Tailwind CSS styling.

## 🚀 Features

- **React 19** with functional components and hooks
- **React Router** for client-side navigation
- **Tailwind CSS v4** for modern utility-first styling
- **Vite** for fast development and building
- **PostCSS** for CSS processing
- **Responsive Design** with mobile-first approach

## 📦 Dependencies

### Core Dependencies
```json
{
  "react": "^19.2.0",
  "react-dom": "^19.2.0",
  "react-router-dom": "^7.13.0"
}
```

### Development Dependencies
```json
{
  "@tailwindcss/postcss": "^4.1.18",
  "autoprefixer": "^10.4.24",
  "postcss": "^8.5.6",
  "tailwindcss": "^4.1.18",
  "vite": "^7.2.4"
}
```

## 🎨 Tailwind CSS Configuration

### Step 1: Install Tailwind CSS

```bash
npm install -D tailwindcss postcss autoprefixer @tailwindcss/postcss
```

### Step 2: Configure Tailwind

Create `tailwind.config.js`:
```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

### Step 3: Configure PostCSS

Create `postcss.config.js`:
```javascript
export default {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
}
```

### Step 4: Add Tailwind to CSS

In `src/index.css`:
```css
@import "tailwindcss";

body {
  background-color: #f9fafb;
  color: #111827;
  font-family: system-ui, -apple-system, sans-serif;
}
```

## ⚙️ Project Structure

```
reactconcept/
├── src/
│   ├── component/
│   │   ├── Header.jsx          # Navigation component
│   │   ├── Home.jsx            # Landing page
│   │   ├── Products.jsx        # Product showcase
│   │   ├── test.jsx            # useState demo
│   │   ├── useeffect.jsx       # useEffect demo
│   │   ├── fetchapi.jsx        # API integration demo
│   │   └── Footer.jsx          # Footer component
│   ├── main.jsx                # App entry point
│   ├── App.jsx                 # Main app component
│   └── index.css              # Global styles
├── tailwind.config.js          # Tailwind configuration
├── postcss.config.js           # PostCSS configuration
├── vite.config.js               # Vite configuration
└── package.json                # Dependencies
```

## 🛠️ Development Setup

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation
```bash
# Clone the project
git clone <repository-url>
cd reactconcept

# Install dependencies
npm install

# Start development server
npm run dev
```

### Available Scripts
```json
{
  "dev": "vite",           # Start development server
  "build": "vite build",   # Build for production
  "preview": "vite preview", # Preview production build
  "lint": "eslint ."       # Run ESLint
}
```

## 🎯 Components Overview

### 1. Header Component
- Sticky navigation with backdrop blur
- Responsive mobile menu
- Active route highlighting
- Professional logo design

### 2. Home Page
- Hero section with gradient text
- Feature cards with icons
- Call-to-action buttons
- Interactive navigation links

### 3. Products Page
- Product grid with hover effects
- Star ratings and reviews
- Category badges
- Add to cart functionality
- Stock status indicators

### 4. Test Component (useState Demo)
- Interactive counter with circular display
- Increase/decrease/reset buttons
- Educational explanation
- State tracking cards

### 5. UseEffect Component
- Registration form with validation
- Live form data preview
- Console logging demonstration
- Educational content

### 6. API Fetch Component
- Real data from JSONPlaceholder API
- Loading states with spinner
- Error handling
- User cards with avatars
- API integration details

## 🎨 Tailwind CSS Usage Examples

### Responsive Design
```jsx
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
  {/* Responsive grid layout */}
</div>
```

### Gradients and Colors
```jsx
<div className="bg-gradient-to-br from-indigo-50 via-white to-purple-50">
  <h1 className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
    Gradient Text
  </h1>
</div>
```

### Hover Effects and Transitions
```jsx
<button className="bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors duration-200 shadow-lg hover:shadow-xl">
  Interactive Button
</button>
```

### Utility Classes
```jsx
<div className="flex items-center justify-between p-6 rounded-2xl shadow-lg">
  {/* Flexbox layout with spacing and shadows */}
</div>
```

## 🔧 Customization

### Adding Custom Colors
In `tailwind.config.js`:
```javascript
theme: {
  extend: {
    colors: {
      'brand': '#667eea',
      'brand-dark': '#5a67d8',
    }
  }
}
```

### Custom Components
In `src/index.css`:
```css
@layer components {
  .btn-primary {
    @apply bg-indigo-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-indigo-700;
  }
}
```

## 📱 Responsive Breakpoints

- **sm**: 640px and up
- **md**: 768px and up  
- **lg**: 1024px and up
- **xl**: 1280px and up
- **2xl**: 1536px and up

## 🚀 Production Build

```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

The build output will be in the `dist/` directory with optimized CSS and JavaScript.

## 🐛 Troubleshooting

### Tailwind CSS Not Working
1. Check if `@import "tailwindcss";` is in `src/index.css`
2. Verify PostCSS configuration in `postcss.config.js`
3. Ensure all dependencies are installed
4. Restart development server

### Common Issues
- **Utility classes not recognized**: Update to Tailwind CSS v4 syntax
- **CSS not updating**: Clear browser cache and restart dev server
- **Build errors**: Check for syntax errors in CSS files

## 📚 Learning Resources

- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [React Documentation](https://react.dev)
- [Vite Documentation](https://vite.dev)
- [React Router Documentation](https://reactrouter.com)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

---

**Built with ❤️ using React, Vite, and Tailwind CSS**
