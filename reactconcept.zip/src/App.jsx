import { Routes, Route } from "react-router-dom";
import Header from "./component/Header";
import Footer from "./component/Footer";
import Home from "./component/Home";
import Products from "./component/Products";
import Test from "./component/test";
import Useeffect from "./component/useeffect";
import ApiFetch from "./component/fetchapi";

function App() {
  return <>
      <Header />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/test" element={<Test />} />
        <Route path="/useeffect" element={<Useeffect />} />
        <Route path="/fetch" element={<ApiFetch />} />
      </Routes>

      <Footer />
  
  </>;
}

export default App;
