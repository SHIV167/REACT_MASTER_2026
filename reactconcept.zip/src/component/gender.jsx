import React from 'react';
import { useState, useEffect } from 'react'



function App() {
  const [name, setName] = useState(null)
  
  nameArray = ['Azaz', 'Alok', 'Sudha', 'Abhi'];
  const paraMeter = nameArray.map(e =>`name[]=&{encodeURIComponen(n)}`.join("&");
  
  useEffect(()=>{fetch('https://api.genderize.io/?').then(res => res.json()).then(data => {console.log(data);setName(data);})},[])
  
  
  
  const styles = {
    main: {
      padding: '20px',
    },
    title: {
      color: '#5C6AC4'
    },
  };

  return (
    <div style={styles.main}>
      <h1 style={styles.title}>Hello, World!</h1>
      <div>

      </div>
    </div>
  )
}

export default Gender
