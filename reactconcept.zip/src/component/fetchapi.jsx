import React, { useEffect, useState } from "react";

const ApiFetch = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch(
          "https://jsonplaceholder.typicode.com/users",
        );

        if (!response.ok) {
          throw new Error("Something went wrong");
        }

        const data = await response.json();
        setUsers(data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-indigo-50 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">API Fetch Demo</h1>
            <p className="text-lg text-gray-600 mb-8">Fetching data from external API</p>
            <div className="inline-flex items-center space-x-2">
              <div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-lg text-gray-600">Loading users...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">API Error</h1>
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg max-w-md mx-auto">
              <p className="font-semibold">Error: {error}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-indigo-50 py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">API Fetch Demo</h1>
          <p className="text-lg text-gray-600">Real-time data from JSONPlaceholder API</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">User List</h2>
              <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                {users.length} users
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {users.map((user) => (
                <div key={user.id} className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 hover:shadow-lg transition-shadow duration-300">
                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
                      <span className="text-white font-bold text-lg">
                        {user.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg font-semibold text-gray-900 truncate">
                        {user.name}
                      </h3>
                      <p className="text-sm text-gray-600 mb-1">
                        @{user.username.toLowerCase()}
                      </p>
                      <p className="text-sm text-indigo-600 mb-2">
                        {user.email}
                      </p>
                      <div className="text-xs text-gray-500">
                        <p>📧 {user.email.split('@')[1]}</p>
                        <p>🌐 {user.website}</p>
                        <p>📱 {user.phone}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 p-4 bg-blue-50 rounded-xl">
              <h3 className="text-sm font-semibold text-blue-900 mb-2">API Integration Details:</h3>
              <div className="text-sm text-blue-700 space-y-1">
                <p><strong>Endpoint:</strong> https://jsonplaceholder.typicode.com/users</p>
                <p><strong>Method:</strong> GET request with fetch API</p>
                <p><strong>Status:</strong> {users.length > 0 ? '✅ Successfully fetched' : '⚠️ No data available'}</p>
              </div>
              <div className="mt-3 text-xs text-blue-600 font-mono bg-white p-2 rounded">
                {'useEffect(() => { fetch("/api/users").then(setUsers); }, []);'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApiFetch;
