import React, { useState, useEffect } from "react";

const Useeffect = () => {
  const [formData, setFormdata] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });

  useEffect(() => {
    console.log("Component mounted with useEffect");
    return () => {
      console.log("Component unmounted");
    };
  }, []);

  const handleInput = (e) => {
    const { name, value } = e.target;
    setFormdata((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-indigo-50 to-blue-50 py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">useEffect Demo</h1>
            <p className="text-lg text-gray-600">Interactive form with side effects</p>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Register Form</h2>

            <div className="space-y-4">
              <div>
                <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">
                  Username
                </label>
                <input
                  type="text"
                  id="username"
                  name="username"
                  placeholder="Enter your username"
                  autoComplete="off"
                  value={formData.username}
                  onChange={handleInput}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  placeholder="Enter your email"
                  autoComplete="off"
                  value={formData.email}
                  onChange={handleInput}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  name="password"
                  id="password"
                  placeholder="Enter your password"
                  autoComplete="off"
                  value={formData.password}
                  onChange={handleInput}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                />
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-2">
                  Confirm Password
                </label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  placeholder="Confirm your password"
                  value={formData.confirmPassword}
                  onChange={handleInput}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                />
              </div>

              <button 
                type="submit" 
                className="w-full bg-indigo-600 text-white py-3 px-4 rounded-xl font-semibold hover:bg-indigo-700 transition-colors duration-200 shadow-lg hover:shadow-xl"
              >
                Create Account
              </button>
            </div>

            <div className="mt-6 p-4 bg-indigo-50 rounded-xl">
              <h3 className="text-sm font-semibold text-indigo-900 mb-2">Live Form Data:</h3>
              <p className="text-sm text-indigo-700">
                My name <span className="font-mono bg-white px-2 py-1 rounded">{formData.username || "..."}</span> is and email <span className="font-mono bg-white px-2 py-1 rounded">{formData.email || "..."}</span> is
              </p>
            </div>

            <div className="mt-4 p-4 bg-purple-50 rounded-xl">
              <h3 className="text-sm font-semibold text-purple-900 mb-2">useEffect Hook Explanation:</h3>
              <p className="text-sm text-purple-700">
                The useEffect hook runs side effects in your components. Check the browser console to see the mount/unmount messages.
              </p>
              <div className="mt-2 text-xs text-purple-600 font-mono bg-white p-2 rounded">
                {'useEffect(() => { console.log("Mounted"); return () => console.log("Unmounted"); }, []);'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Useeffect;
