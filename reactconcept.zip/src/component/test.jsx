import React, { useEffect, useState } from "react";

const Test = () => {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    document.title = `Count: ${count}`;
  }, [count]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">useState Counter Demo</h1>
            <p className="text-lg text-gray-600">Interactive example of React's useState hook</p>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-32 h-32 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full mb-6">
                <span className="text-4xl font-bold text-white">{count}</span>
              </div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">Current Count</h2>
              <p className="text-gray-600">Click the buttons below to modify the count</p>
            </div>

            <div className="flex items-center justify-center space-x-4">
              <button 
                onClick={() => setCount(count - 1)}
                disabled={count === 0}
                className="px-6 py-3 bg-red-500 text-white rounded-xl font-semibold hover:bg-red-600 transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-red-500"
              >
                <div className="flex items-center space-x-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                  </svg>
                  <span>Decrease</span>
                </div>
              </button>

              <button 
                onClick={() => setCount(0)}
                className="px-6 py-3 bg-gray-500 text-white rounded-xl font-semibold hover:bg-gray-600 transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <div className="flex items-center space-x-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  <span>Reset</span>
                </div>
              </button>

              <button 
                onClick={() => setCount(count + 1)}
                className="px-6 py-3 bg-green-500 text-white rounded-xl font-semibold hover:bg-green-600 transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <div className="flex items-center space-x-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  <span>Increase</span>
                </div>
              </button>
            </div>

            <div className="mt-8 p-4 bg-indigo-50 rounded-xl">
              <h3 className="text-sm font-semibold text-indigo-900 mb-2">useState Hook Explanation:</h3>
              <p className="text-sm text-indigo-700">
                The useState hook returns an array with two elements: the current state value and a function to update it. 
                When you call the setter function, React re-renders the component with the new state value.
              </p>
              <div className="mt-3 text-xs text-indigo-600 font-mono bg-white p-2 rounded">
                const [count, setCount] = useState(0);
              </div>
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-xl shadow-md">
              <h4 className="font-semibold text-gray-900 mb-2">State Value</h4>
              <p className="text-2xl font-bold text-indigo-600">{count}</p>
            </div>
            <div className="bg-white p-4 rounded-xl shadow-md">
              <h4 className="font-semibold text-gray-900 mb-2">Document Title</h4>
              <p className="text-sm text-gray-600">Count: {count}</p>
            </div>
            <div className="bg-white p-4 rounded-xl shadow-md">
              <h4 className="font-semibold text-gray-900 mb-2">Re-renders</h4>
              <p className="text-sm text-gray-600">Updates on each click</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Test;
